﻿using System;

public interface ISortStrategy
{
    void Sort(int[] array);
}
public class InsertionSort : ISortStrategy
{
    public void Sort(int[] array)
    {
        for (int i = 1; i < array.Length; i++)
        {
            int key = array[i];
            int j = i - 1;

            while (j >= 0 && array[j] > key)
            {
                array[j + 1] = array[j];
                j--;
            }
            array[j + 1] = key;
        }
    }
}
public class SelectionSort : ISortStrategy
{
    public void Sort(int[] array)
    {
        for (int i = 0; i < array.Length - 1; i++)
        {
            int minIndex = i;
            for (int j = i + 1; j < array.Length; j++)
            {
                if (array[j] < array[minIndex])
                {
                    minIndex = j;
                }
            }

            int temp = array[minIndex];
            array[minIndex] = array[i];
            array[i] = temp;
        }
    }
}
public class MergeSort : ISortStrategy
{
    public void Sort(int[] array)
    {
        MergeSortRecursive(array, 0, array.Length - 1);
    }

    private void MergeSortRecursive(int[] array, int left, int right)
    {
        if (left < right)
        {
            int middle = (left + right) / 2;
            MergeSortRecursive(array, left, middle);
            MergeSortRecursive(array, middle + 1, right);
            Merge(array, left, middle, right);
        }
    }

    private void Merge(int[] array, int left, int middle, int right)
    {
        int n1 = middle - left + 1;
        int n2 = right - middle;

        int[] leftArray = new int[n1];
        int[] rightArray = new int[n2];

        Array.Copy(array, left, leftArray, 0, n1);
        Array.Copy(array, middle + 1, rightArray, 0, n2);

        int i = 0, j = 0, k = left;
        while (i < n1 && j < n2)
        {
            if (leftArray[i] <= rightArray[j])
                array[k++] = leftArray[i++];
            else
                array[k++] = rightArray[j++];
        }

        while (i < n1)
            array[k++] = leftArray[i++];

        while (j < n2)
            array[k++] = rightArray[j++];
    }
}
public class ShellSort : ISortStrategy
{
    public void Sort(int[] array)
    {
        int n = array.Length;
        for (int gap = n / 2; gap > 0; gap /= 2)
        {
            for (int i = gap; i < n; i++)
            {
                int temp = array[i];
                int j;
                for (j = i; j >= gap && array[j - gap] > temp; j -= gap)
                {
                    array[j] = array[j - gap];
                }
                array[j] = temp;
            }
        }
    }
}
public class Sorter
{
    private ISortStrategy _sortStrategy;

    public Sorter(ISortStrategy sortStrategy)
    {
        _sortStrategy = sortStrategy;
    }

    public void SetStrategy(ISortStrategy sortStrategy)
    {
        _sortStrategy = sortStrategy;
    }

    public void Sort(int[] array)
    {
        _sortStrategy.Sort(array);
    }
}

class Program
{
    static void Main()
    {
        int[] array = { 64, 34, 25, 12, 22, 11, 90 };
        Console.WriteLine("Original Array: " + string.Join(", ", array));

        MeasureSortTime(new InsertionSort(), array, "Insertion Sort");
        MeasureSortTime(new SelectionSort(), array, "Selection Sort");
        MeasureSortTime(new MergeSort(), array, "Merge Sort");
        MeasureSortTime(new ShellSort(), array, "Shell Sort");
    }

    static void MeasureSortTime(ISortStrategy sortStrategy, int[] array, string name)
    {
        int[] copy = (int[])array.Clone(); 
        Sorter sorter = new Sorter(sortStrategy);

        DateTime startTime = DateTime.Now;
        sorter.Sort(copy);
        DateTime endTime = DateTime.Now;

        double elapsedMilliseconds = (endTime - startTime).TotalMilliseconds;

        Console.WriteLine($"{name} Result: " + string.Join(", ", copy));
        Console.WriteLine($"{name} Execution Time: {elapsedMilliseconds} ms\n");
    }
}

