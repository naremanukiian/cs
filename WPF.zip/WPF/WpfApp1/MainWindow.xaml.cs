﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private Person[] people = new Person[0];
        private int idCounter = 1;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddPerson(string name, int age, string address)
        {
            Array.Resize(ref people, people.Length + 1);
            people[^1] = new Person { Id = idCounter++, Name = name, Age = age, Address = address };
            DisplayPeople();
        }

        private void DisplayPeople()
        {
            LstPeople.Items.Clear();
            foreach (var person in people)
            {
                LstPeople.Items.Add(person);
            }
        }

        private void SortByAge()
        {
            Array.Sort(people, (x, y) => x.Age.CompareTo(y.Age));
            DisplayPeople();
        }

        private void SortByName()
        {
            Array.Sort(people, (x, y) => string.Compare(x.Name, y.Name, StringComparison.OrdinalIgnoreCase));
            DisplayPeople();
        }

        private void SearchByAge(int age)
        {
            LstPeople.Items.Clear();
            foreach (var person in people.Where(p => p.Age == age))
            {
                LstPeople.Items.Add(person);
            }
        }

        private void SearchByName(string name)
        {
            LstPeople.Items.Clear();
            foreach (var person in people.Where(p => p.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
            {
                LstPeople.Items.Add(person);
            }
        }

        private void RemoveByAge(int age)
        {
            people = people.Where(p => p.Age != age).ToArray();
            DisplayPeople();
        }

        private void RemoveByName(string name)
        {
            people = people.Where(p => !p.Name.Equals(name, StringComparison.OrdinalIgnoreCase)).ToArray();
            DisplayPeople();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(TxtAge.Text, out int age) && !string.IsNullOrWhiteSpace(TxtName.Text) && !string.IsNullOrWhiteSpace(TxtAddress.Text))
            {
                AddPerson(TxtName.Text, age, TxtAddress.Text);
                TxtName.Clear();
                TxtAge.Clear();
                TxtAddress.Clear();
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter a valid Name, Age, and Address.");
            }
        }

        private void BtnSortByAge_Click(object sender, RoutedEventArgs e) => SortByAge();
        private void BtnSortByName_Click(object sender, RoutedEventArgs e) => SortByName();

        private void BtnSearchByAge_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(TxtAge.Text, out int age))
                SearchByAge(age);
            else
                MessageBox.Show("Enter a valid age.");
        }

        private void BtnSearchByName_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(TxtName.Text))
                SearchByName(TxtName.Text);
            else
                MessageBox.Show("Enter a valid name.");
        }

        private void BtnRemoveByAge_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(TxtAge.Text, out int age))
                RemoveByAge(age);
            else
                MessageBox.Show("Enter a valid age to remove.");
        }

        private void BtnRemoveByName_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(TxtName.Text))
                RemoveByName(TxtName.Text);
            else
                MessageBox.Show("Enter a valid name to remove.");
        }

        // Placeholder Handling
        private void TxtName_GotFocus(object sender, RoutedEventArgs e)
        {
            if (TxtName.Text == "Enter Name") TxtName.Text = "";
        }

        private void TxtName_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtName.Text)) TxtName.Text = "Enter Name";
        }

        private void TxtAge_GotFocus(object sender, RoutedEventArgs e)
        {
            if (TxtAge.Text == "Enter Age") TxtAge.Text = "";
        }

        private void TxtAge_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtAge.Text)) TxtAge.Text = "Enter Age";
        }

        private void TxtAddress_GotFocus(object sender, RoutedEventArgs e)
        {
            if (TxtAddress.Text == "Enter Address") TxtAddress.Text = "";
        }

        private void TxtAddress_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtAddress.Text)) TxtAddress.Text = "Enter Address";
        }
    }
}