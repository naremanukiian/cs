﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public struct Person
    {
        public int Id;
        public string Name;
        public int Age;
        public string Address;

        public override string ToString() => $"ID: {Id}, Name: {Name}, Age: {Age}, Address: {Address}";
    }
}