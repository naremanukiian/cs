﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Diagnostics;

namespace SortingTemplatePattern
{
    abstract class SortAlgorithm
    {
        protected int[] array;

        public void SetArray(int[] arr)
        {
            int length = 10; 
            array = new int[length];
            for (int i = 0; i < length; i++)
            {
                array[i] = arr[i];
            }
        }
        public void Sort()
        {
            if (array == null) return;
            ExecuteSort();
        }
        protected abstract void ExecuteSort();
        protected void Swap(int i, int j)
        {
            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        public void PrintSortedArray()
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write(array[i] + " ");
            }
            Console.WriteLine();
        }
    }
    class BubbleSort : SortAlgorithm
    {
        protected override void ExecuteSort()
        {
            for (int i = 0; i < 10 - 1; i++)
            {
                for (int j = 0; j < 10 - i - 1; j++)
                {
                    if (array[j] > array[j + 1])
                    {
                        Swap(j, j + 1);
                    }
                }
            }
        }
    }
    class InsertionSort : SortAlgorithm
    {
        protected override void ExecuteSort()
        {
            for (int i = 1; i < 10; i++)
            {
                int key = array[i];
                int j = i - 1;

                while (j >= 0 && array[j] > key)
                {
                    array[j + 1] = array[j];
                    j--;
                }
                array[j + 1] = key;
            }
        }
    }
    class SelectionSort : SortAlgorithm
    {
        protected override void ExecuteSort()
        {
            for (int i = 0; i < 10 - 1; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < 10; j++)
                {
                    if (array[j] < array[minIndex])
                    {
                        minIndex = j;
                    }
                }

                if (minIndex != i)
                {
                    Swap(i, minIndex);
                }
            }
        }
    }

    class Program
    {
        static void Main()
        {
            int[] array = GenerateRandomArray();

            Console.WriteLine("Original Array:");
            PrintArray(array);
            Console.WriteLine();

            TestSort("Bubble Sort", new BubbleSort(), array);
            TestSort("Insertion Sort", new InsertionSort(), array);
            TestSort("Selection Sort", new SelectionSort(), array);
        }
        static void TestSort(string name, SortAlgorithm algorithm, int[] array)
        {
            int[] copy = new int[10];
            for (int i = 0; i < 10; i++)
            {
                copy[i] = array[i];
            }

            algorithm.SetArray(copy);

            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            algorithm.Sort();
            stopwatch.Stop();

            Console.WriteLine($"{name} completed in {stopwatch.ElapsedMilliseconds} ms");
            Console.Write("Sorted Array: ");
            algorithm.PrintSortedArray();
            Console.WriteLine();
        }
        static int[] GenerateRandomArray()
        {
            Random rand = new Random();
            int[] array = new int[10];

            for (int i = 0; i < 10; i++)
            {
                array[i] = rand.Next(0, 100);
            }

            return array;
        }
        static void PrintArray(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write(array[i] + " ");
            }
            Console.WriteLine();
        }
    }
}
