﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Linq;


namespace WpfApp3
{
    public struct Person
    {
        public int Id;
        public string Name;
        public int Age;
        public string Address;

        public override string ToString() => $"ID: {Id}, Name: {Name}, Age: {Age}, Address: {Address}";
    }
}

namespace WpfApp3
{
    public partial class MainWindow : Window
    {
        private Person[] people = new Person[0];
        private int idCounter = 1;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddPerson(string name, int age, string address)
        {
            Array.Resize(ref people, people.Length + 1);
            people[^1] = new Person { Id = idCounter++, Name = name, Age = age, Address = address };
            DisplayPeople();
        }

        private void DisplayPeople()
        {
            lstPeople.Items.Clear();
            foreach (var person in people)
            {
                lstPeople.Items.Add(person);
            }
        }

        private void SortByAge()
        {
            Array.Sort(people, (x, y) => x.Age.CompareTo(y.Age));
            DisplayPeople();
        }

        private void SortByName()
        {
            Array.Sort(people, (x, y) => string.Compare(x.Name, y.Name, StringComparison.OrdinalIgnoreCase));
            DisplayPeople();
        }

        private void SearchByAge(int age)
        {
            lstPeople.Items.Clear();
            foreach (var person in people.Where(p => p.Age == age))
            {
                lstPeople.Items.Add(person);
            }
        }

        private void SearchByName(string name)
        {
            lstPeople.Items.Clear();
            foreach (var person in people.Where(p => p.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
            {
                lstPeople.Items.Add(person);
            }
        }

        private void RemoveByAge(int age)
        {
            people = people.Where(p => p.Age != age).ToArray();
            DisplayPeople();
        }

        private void RemoveByName(string name)
        {
            people = people.Where(p => !p.Name.Equals(name, StringComparison.OrdinalIgnoreCase)).ToArray();
            DisplayPeople();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(txtAge.Text, out int age) && !string.IsNullOrWhiteSpace(txtName.Text) && !string.IsNullOrWhiteSpace(txtAddress.Text))
            {
                AddPerson(txtName.Text, age, txtAddress.Text);
                txtName.Clear();
                txtAge.Clear();
                txtAddress.Clear();
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter a valid Name, Age, and Address.");
            }
        }

        private void BtnSortByAge_Click(object sender, RoutedEventArgs e) => SortByAge();
        private void BtnSortByName_Click(object sender, RoutedEventArgs e) => SortByName();

        private void BtnSearchByAge_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(txtAge.Text, out int age))
                SearchByAge(age);
            else
                MessageBox.Show("Enter a valid age.");
        }

        private void BtnSearchByName_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtName.Text))
                SearchByName(txtName.Text);
            else
                MessageBox.Show("Enter a valid name.");
        }

        private void BtnRemoveByAge_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(txtAge.Text, out int age))
                RemoveByAge(age);
            else
                MessageBox.Show("Enter a valid age to remove.");
        }

        private void BtnRemoveByName_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtName.Text))
                RemoveByName(txtName.Text);
            else
                MessageBox.Show("Enter a valid name to remove.");
        }

        // Placeholder Handling
        private void TxtName_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtName.Text == "Enter Name") txtName.Text = "";
        }

        private void TxtName_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text)) txtName.Text = "Enter Name";
        }

        private void TxtAge_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtAge.Text == "Enter Age") txtAge.Text = "";
        }

        private void TxtAge_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtAge.Text)) txtAge.Text = "Enter Age";
        }

        private void TxtAddress_GotFocus(object sender, RoutedEventArgs e)
        {
            if (txtAddress.Text == "Enter Address") txtAddress.Text = "";
        }

        private void TxtAddress_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtAddress.Text)) txtAddress.Text = "Enter Address";
        }
    }
}

